# Prototype Handoff 模板

在 `prd.md` 结尾输出。

```yaml
prototype_handoff:
  product_name:
  prototype_goal:
  target_users:
  primary_scenarios:

  page_inventory:
    - page_id:
      page_name:
      purpose:
      entry:
      exit:
      primary_actions:
      secondary_actions:
      states:
      permissions:

  primary_flow:
  secondary_flows:

  global_business_rules:
  shared_data_objects:
  permissions:

  dynamic_modules:
    - module_name:
      show_condition:
      hide_condition:
      data_source:
      failure_behavior:

  state_requirements:
    loading:
    empty:
    success:
    partial_success:
    error:
    no_permission:
    long_task:
    cancelled:

  error_requirements:
  design_constraints:
  responsive_requirements:

  must_be_clickable:
  prototype_out_of_scope:
  mock_data_requirements:
  p0_open_questions:
```

正文补充：

## 原型覆盖范围

- 必须覆盖的页面
- 必须覆盖的核心流程
- 必须实现的状态
- 必须可点击的操作
- 可使用模拟数据的内容
- 不在原型范围内的内容

## 原型演示路径

按顺序说明：

```text
进入页面
→ 执行核心操作
→ 查看结果
→ 触发异常或分支
→ 返回或结束
```

## 不允许原型 Skill 自行决定

列出：

- 未确认业务规则
- 权限和收费规则
- 数据口径
- 安全和合规规则
- 发布范围
