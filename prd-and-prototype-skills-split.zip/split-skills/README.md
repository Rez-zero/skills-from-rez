# Split Skills

包含两个可配套使用的 Claude Code Skill：

```text
prd-generator/
  SKILL.md
  references/
    prd-structure.md
    page-templates.md
    ai-agent-template.md
    quality-checklist.md
    prototype-handoff.md

ai-prototype-plan/
  SKILL.md
  references/
    brief-structure.md
    page-component-spec.md
    state-error-patterns.md
    project-layout.md
    review-checklist.md
```

没有 `scripts/`。

使用时可将两个文件夹复制到：

```text
项目级：.claude/skills/
个人级：~/.claude/skills/
```

推荐顺序：

```text
prd-generator
→ prd.md
→ ai-prototype-plan
→ brief.md
```

主 `SKILL.md` 仅保留：

- Skill 定位
- 触发条件
- 必读输入
- 核心执行流程
- 缺失信息处理
- 输出与禁止事项

详细模板和检查清单均放在 `references/`，且只使用一层引用。
