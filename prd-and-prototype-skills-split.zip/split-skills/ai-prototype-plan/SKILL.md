---
name: ai-prototype-plan
description: >
  将已确认的 PRD、需求说明、页面截图和项目上下文，
  转换为可供 AI 原型工具或前端原型生成流程直接执行的 brief.md。
  重点定义页面、组件、交互、状态、异常、跳转、视觉约束、
  响应式要求、演示路径和产品经理 Review。
version: 1.1.0
language: zh-CN
output_format: markdown
primary_output: brief.md
depends_on:
  - prd-generator
---

# AI Prototype Plan

## 1. 目标

把已经确认的产品规则转换为可生成、可点击、可评审的 AI 原型 Brief。

推荐链路：

```text
prd.md
→ ai-prototype-plan
→ brief.md
→ AI 原型 / Vibe Coding
→ 产品经理 Review
```

本 Skill 负责：

- 页面结构；
- 组件；
- 信息层级；
- 交互；
- 页面状态；
- 异常和恢复；
- 跳转与状态保留；
- 动态模块；
- 响应式；
- 原型演示路径；
- Review 清单。

不负责重新决定业务规则。

---

## 2. 触发场景

在以下请求中使用：

- 将 PRD 转换为 AI 原型 Brief；
- 生成、补全或重构 `brief.md`；
- 在既有 PRD 下补全页面、组件、状态和交互；
- 为 AI 原型工具、低代码工具或前端生成工具准备输入。

若缺少完整 PRD：

- 核心业务规则不清时，先使用 `prd-generator`；
- 只有页面级细节缺失时，可使用保守假设并标记；
- 不得在原型阶段擅自补充收费、权限或数据口径。

---

## 3. 必读输入

按优先级读取：

1. `prd.md`；
2. `prototype_handoff`；
3. `spec.md`、README 和项目规范；
4. 现有页面、路由、组件和 Design System；
5. 截图、原型、竞品和视觉参考；
6. 相关数据字段和权限说明。

建立：

- 已确认规则；
- 可复用页面和组件；
- 设计约束；
- 冲突；
- 假设；
- P0 待确认项。

---

## 4. 执行流程

### Step 1：确认原型范围

明确：

- 原型目标；
- 目标用户；
- 页面清单；
- 演示主流程；
- 必须可点击的操作；
- 必须展示的状态；
- 原型不覆盖的内容；
- 可使用模拟数据的内容。

### Step 2：读取模板

- Brief 标准结构：`references/brief-structure.md`
- 页面与组件规范：`references/page-component-spec.md`
- 状态和异常模式：`references/state-error-patterns.md`
- 项目与落盘规范：`references/project-layout.md`
- Review 清单：`references/review-checklist.md`

### Step 3：建立页面模型

每个页面至少定义：

```yaml
page_id:
page_name:
purpose:
entry:
exit:
primary_actions:
secondary_actions:
data:
states:
permissions:
transitions:
```

### Step 4：建立组件模型

每个组件至少定义：

```yaml
component_name:
purpose:
show_condition:
fields:
default_state:
interaction:
success_feedback:
error_feedback:
permissions:
responsive_behavior:
```

### Step 5：补全状态与异常

必须覆盖适用的：

- 初始；
- 加载；
- 空数据；
- 成功；
- 部分成功；
- 失败；
- 超时；
- 无权限；
- 长任务；
- 取消；
- 重试；
- 刷新；
- 返回；
- 数据失效。

异常模式参考 `references/state-error-patterns.md`。

### Step 6：生成 `brief.md`

使用 `references/brief-structure.md`。

不得：

- 重新发明 PRD 中没有确认的业务规则；
- 把待确认项写成确定交互；
- 为了“好看”删除重要信息；
- 只写视觉，不写状态和交互。

### Step 7：一致性检查

对照 `prd.md` 检查：

- 页面范围；
- 用户角色；
- 权限；
- 业务规则；
- 动态模块；
- 状态；
- 跳转；
- 数据；
- 待确认项。

发现规则漂移时，以 PRD 为准；若 PRD 内部冲突，标记并停止擅自决策。

### Step 8：PM Review

读取 `references/review-checklist.md`，在 Brief 末尾输出产品经理 Review 清单。

---

## 5. 缺失信息处理

| 类型 | 处理 |
|---|---|
| 核心业务、权限、收费、数据口径不清 | P0，必须确认 |
| 页面布局或普通交互不清 | 使用保守、可回退方案并标记 |
| 视觉细节不清 | 继承 Design System；没有时使用中性 B 端风格 |
| 响应式范围不清 | 根据产品场景提出建议并标记 |

所有假设集中写入“假设与待确认”，不得散落隐藏。

---

## 6. 输出

主输出：

```text
brief.md
```

可选输出：

```text
review.md
assumptions.md
routes.md
states.md
prototype-notes.md
```

默认回复只汇报：

- 文件位置；
- 页面数量；
- 核心流程；
- P0/P1 待确认；
- 与 PRD 的一致性检查结果。

---

## 7. 禁止事项

不得：

- 跳过 PRD 直接编造关键业务规则；
- 只描述页面外观；
- 省略入口、出口、返回和失败路径；
- 省略 Loading、Empty、Error 和无权限状态；
- 将动态模块固定展示；
- 把页面筛选和重新发起任务混淆；
- 新增未经确认的收费或权限规则；
- 生成无法点击、无法演示的“静态说明稿”；
- 在 Brief 中与 PRD 使用不同字段或不同口径。
