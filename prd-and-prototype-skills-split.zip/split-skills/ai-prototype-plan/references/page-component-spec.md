# 页面与组件规格

## 1. 页面规格

每个页面至少包含：

```yaml
page_id:
page_name:
purpose:
users:
entry:
exit:
route:
data_source:
primary_actions:
secondary_actions:
states:
permissions:
refresh_behavior:
return_behavior:
```

必须说明：

- 从哪里进入；
- 通过什么触发；
- 跳转到哪里；
- 返回时保留什么；
- 刷新时保留什么；
- 是否创建新任务或新数据；
- 异常时如何回退。

## 2. 组件规格

每个组件至少包含：

```yaml
component_name:
purpose:
show_condition:
hide_condition:
fields:
default_state:
hover_state:
focus_state:
selected_state:
disabled_state:
loading_state:
interaction:
success_feedback:
error_feedback:
permissions:
responsive_behavior:
```

## 3. 常见组件要求

### 按钮

- 文案表达点击结果
- 主次层级明确
- Disabled 条件明确
- Loading 避免重复提交
- 成功和失败有反馈
- 高风险操作需要确认

### 表格和列表

- 字段
- 默认排序
- 筛选
- 分页或虚拟滚动
- 单条和批量操作
- 空、加载、错误
- 选择状态
- 删除和撤销
- 性能要求

### 表单

- 字段类型
- 必填
- 默认值
- 校验
- 联动
- 显隐
- 保存和提交
- 未保存提醒
- 错误定位

### 卡片

- 展示字段
- 展开与折叠
- 点击区域
- 状态标签
- 操作入口
- 长文本处理
- 空字段处理

### 弹窗和抽屉

- 触发
- 关闭
- 遮罩点击
- ESC
- 二次确认
- 提交状态
- 内容过长
- 移动端适配

### 动态模块

- 出现条件
- 隐藏条件
- 数据来源
- 失败是否阻断主流程
- 目录是否同步出现
- 导出是否包含
- 空状态还是整块隐藏

## 4. 页面关系

明确区分：

- 页面筛选：改变当前结果展示；
- 新任务：改变输入和数据；
- 能力升级：输入不变但执行更深流程；
- 详情查看：不改变原始结果；
- 编辑：改变工作副本；
- 导出和分享：生成当前快照。
