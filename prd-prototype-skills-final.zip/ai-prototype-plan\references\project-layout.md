# 项目与落盘规范

## 1. 优先继承项目结构

执行前确认：

- 是否已有原型目录
- 是否已有页面路由
- 是否已有命名规范
- 是否已有组件和资源目录
- 是否已有 `brief.md`

不得在未检查现有结构前创建平行目录。

## 2. 默认目录

项目没有规范时：

```text
/prototype
  /docs
    brief.md
    review.md
    assumptions.md
  /pages
  /components
  /assets
  /references
```

## 3. 页面命名

```yaml
page_name:
route:
purpose:
entry:
exit:
primary_actions:
secondary_actions:
states:
permissions:
```

## 4. 文件规则

- 主文件命名为 `brief.md`
- 版本记录写在文档中
- 不使用 `final-v2-new.md`
- 不覆盖用户未要求修改的文件
- 不修改无关代码、配置或资源


## 5. 与原型版本仓库的关系

启用统一工作区时，以 `prototype-registry.md` 为准。项目正式代码目录只作为批准版本后续集成目标，不作为原型历史版本仓库。
