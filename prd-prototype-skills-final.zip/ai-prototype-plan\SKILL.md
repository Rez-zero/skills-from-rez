---
name: ai-prototype-plan
description: >
  将已确认的 PRD、需求说明、页面截图和项目上下文，
  转换为可供 AI 原型工具或前端原型生成流程直接执行的 brief.md。
  重点定义页面、组件、交互、状态、异常、跳转、视觉约束、
  响应式要求、演示路径和产品经理 Review。
version: 1.1.0
language: zh-CN
output_format: markdown
primary_output: brief.md
depends_on:
  - prd-generator
---

# AI Prototype Plan

## 1. 目标

把已经确认的产品规则转换为可生成、可点击、可评审的 AI 原型 Brief。

推荐链路：

```text
prd.md
→ ai-prototype-plan
→ brief.md
→ AI 原型 / Vibe Coding
→ 产品经理 Review
```

本 Skill 负责：

- 页面结构；
- 组件；
- 信息层级；
- 交互；
- 页面状态；
- 异常和恢复；
- 跳转与状态保留；
- 动态模块；
- 响应式；
- 原型演示路径；
- Review 清单。

不负责重新决定业务规则。

---

## 2. 触发场景

在以下请求中使用：

- 将 PRD 转换为 AI 原型 Brief；
- 生成、补全或重构 `brief.md`；
- 在既有 PRD 下补全页面、组件、状态和交互；
- 为 AI 原型工具、低代码工具或前端生成工具准备输入。

若缺少完整 PRD：

- 核心业务规则不清时，先使用 `prd-generator`；
- 只有页面级细节缺失时，可使用保守假设并标记；
- 不得在原型阶段擅自补充收费、权限或数据口径。

---

## 3. 必读输入

按优先级读取：

1. `prd.md`；
2. `prototype_handoff`；
3. `spec.md`、README 和项目规范；
4. 现有页面、路由、组件和 Design System；
5. 截图、原型、竞品和视觉参考；
6. 相关数据字段和权限说明。

建立：

- 已确认规则；
- 可复用页面和组件；
- 设计约束；
- 冲突；
- 假设；
- P0 待确认项。

---

## 4. 执行流程

### Step 1：定位统一原型工作区

读取 `references/prototype-registry.md`。

确定 `product_key`、`feature_key`、`prototype_id`、来源 PRD 文档与版本，以及本次是新建、整体更新还是局部页面更新。不得将页面散落到项目根目录或随机临时目录。

### Step 2：确认原型范围

明确：

- 原型目标；
- 目标用户；
- 页面清单；
- 演示主流程；
- 必须可点击的操作；
- 必须展示的状态；
- 原型不覆盖的内容；
- 可使用模拟数据的内容。

### Step 3：读取模板

- Brief 标准结构：`references/brief-structure.md`
- 页面与组件规范：`references/page-component-spec.md`
- 状态和异常模式：`references/state-error-patterns.md`
- 项目与落盘规范：`references/project-layout.md`
- Review 清单：`references/review-checklist.md`
- 原型工作区和版本管理：`references/prototype-registry.md`

### Step 4：建立页面模型

每个页面至少定义：

```yaml
page_id:
page_name:
purpose:
entry:
exit:
primary_actions:
secondary_actions:
data:
states:
permissions:
transitions:
```

### Step 5：建立组件模型

每个组件至少定义：

```yaml
component_name:
purpose:
show_condition:
fields:
default_state:
interaction:
success_feedback:
error_feedback:
permissions:
responsive_behavior:
```

### Step 6：补全状态与异常

必须覆盖适用的：

- 初始；
- 加载；
- 空数据；
- 成功；
- 部分成功；
- 失败；
- 超时；
- 无权限；
- 长任务；
- 取消；
- 重试；
- 刷新；
- 返回；
- 数据失效。

异常模式参考 `references/state-error-patterns.md`。

### Step 7：生成 `brief.md`

使用 `references/brief-structure.md`。

不得：

- 重新发明 PRD 中没有确认的业务规则；
- 把待确认项写成确定交互；
- 为了“好看”删除重要信息；
- 只写视觉，不写状态和交互。

### Step 8：生成页面 Manifest

按 `references/prototype-registry.md` 生成 `manifest.yaml`，统一登记页面、路由、页面文件、规格、组件、Assets、模拟数据、状态和演示流程。

### Step 9：一致性检查

对照 `prd.md` 检查：

- 页面范围；
- 用户角色；
- 权限；
- 业务规则；
- 动态模块；
- 状态；
- 跳转；
- 数据；
- 待确认项。

发现规则漂移时，以 PRD 为准；若 PRD 内部冲突，标记并停止擅自决策。

### Step 10：写入原型版本仓库

按 `references/prototype-registry.md`：

- 自动生成 `prototype_version_id`；
- 保存完整原型版本；
- 生成变更摘要；
- 更新 `current.yaml`、`registry.yaml` 和 `catalog.md`；
- 维护收藏、评审、批准和归档状态；
- 绑定具体 PRD 版本；
- PRD 变化时标记原型是否过期。

局部页面更新也必须形成新版本，不得修改旧版本。

### Step 11：PM Review

读取 `references/review-checklist.md`，在 Brief 末尾输出产品经理 Review 清单。

---

## 5. 缺失信息处理

| 类型 | 处理 |
|---|---|
| 核心业务、权限、收费、数据口径不清 | P0，必须确认 |
| 页面布局或普通交互不清 | 使用保守、可回退方案并标记 |
| 视觉细节不清 | 继承 Design System；没有时使用中性 B 端风格 |
| 响应式范围不清 | 根据产品场景提出建议并标记 |

所有假设集中写入“假设与待确认”，不得散落隐藏。

---

## 6. 输出

主输出为统一原型版本目录：

```text
D:\product-workspace\<product-key>\<feature-key>\prototype\versions\<prototype-version-id>\
```

至少包含：`brief.md`、`manifest.yaml`、`metadata.yaml`、`change-summary.md`、`pages/`、`components/`、`assets/`、`data/`、`reviews/` 和 `snapshots/`。

可选输出：

```text
review.md
assumptions.md
routes.md
states.md
prototype-notes.md
```

### 路径可视化（每次输出必须）

每次生成或更新完成后，回复末尾必须输出统一的「文件位置卡片」，不得只写相对路径或含糊表述：

```text
📁 你的文件在这里

D:\product-workspace\<product-key>\<feature-key>\prototype\versions\<prototype-version-id>\
├── brief.md
├── manifest.yaml
├── metadata.yaml
├── change-summary.md
├── pages\
│   ├── P-001-<page-key>\
│   ├── P-002-<page-key>\
│   └── ...
├── components\
├── assets\
├── data\
├── reviews\
└── snapshots\

🔗 已为你打开该文件夹（如未弹出窗口可忽略）
```

要求：

- 路径必须写完整绝对路径；
- 目录树只展示本次实际生成或更新的文件，不虚构；
- 生成完成后执行 `explorer.exe "D:\product-workspace\..."` 打开产出目录，让用户直接看到文件夹（执行失败或环境不支持时忽略，不影响主流程）；
- 若产出目录已存在且本次未产生新文件，仍需在回复中指明当前文件位置。

默认回复只汇报：

- 文件位置（按上方路径卡片格式，必含完整路径与目录树）；
- 页面数量；
- 核心流程；
- P0/P1 待确认；
- 与 PRD 的一致性检查结果。

---

## 7. 禁止事项

不得：

- 跳过 PRD 直接编造关键业务规则；
- 只描述页面外观；
- 省略入口、出口、返回和失败路径；
- 省略 Loading、Empty、Error 和无权限状态；
- 将动态模块固定展示；
- 把页面筛选和重新发起任务混淆；
- 新增未经确认的收费或权限规则；
- 生成无法点击、无法演示的“静态说明稿”；
- 在 Brief 中与 PRD 使用不同字段或不同口径。
