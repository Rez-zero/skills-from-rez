# 原型工作区与版本管理

本规范用于统一收纳 AI 生成的页面、组件、Assets、模拟数据和截图，避免原型散落在不同目录。

## 1. 工作区根目录

工作区根目录为：

```
D:\product-workspace\
```

所有原型文件统一收纳在此目录下。

## 2. 默认目录结构

优先继承已有目录。没有规范时使用：

```text
D:\product-workspace\
  registry.yaml
  catalog.md

  /<product-key>
    /<feature-key>
      /prd
      /prototype
        registry.yaml
        current.yaml
        catalog.md

        /versions
          /<prototype-version-id>
            brief.md
            manifest.yaml
            metadata.yaml
            change-summary.md

            /pages
              /<page-id>-<page-key>
                page.*
                page-spec.md

            /components
            /assets
            /data
            /reviews
            /snapshots
```

所有原型页面必须位于当前原型版本的 `pages/` 中。

## 2. 原型标识

```yaml
prototype_id:
prototype_version_id:
product_key:
feature_key:
source_prd_document_id:
source_prd_version_id:
status: draft | in_review | approved | superseded | archived
starred: false
stale: false
created_at:
updated_at:
content_hash:
```

规则：

- `prototype_id` 在同一功能内保持不变；
- `prototype_version_id` 自动生成；
- 每个原型版本绑定一个明确的 PRD 版本；
- 已批准或归档的原型不得覆盖。

## 3. 页面 Manifest

每个原型版本必须生成 `manifest.yaml`：

```yaml
prototype_id:
prototype_version_id:
source_prd_version_id:

pages:
  - page_id:
    page_key:
    page_name:
    route:
    purpose:
    entry:
    exit:
    file_path:
    spec_path:
    status: planned | generated | reviewed | approved
    shared_components: []
    states: []
    dependencies: []

shared_components:
  - component_id:
    name:
    path:
    used_by: []

assets:
  - asset_id:
    type:
    path:
    used_by: []

demo_flows:
  - flow_id:
    name:
    start_page:
    steps: []
```

页面新增、重命名、移动和删除后，必须同步更新 Manifest。

## 4. 版本生成流程

```text
读取来源 PRD 版本
→ 读取 prototype registry
→ 判断新建、整体更新或局部更新
→ 创建 prototype_version_id
→ 继承未变化的页面
→ 生成或修改目标页面
→ 更新 manifest.yaml
→ 生成 change-summary.md
→ 更新 current.yaml、registry.yaml 和 catalog.md
```

不得直接修改旧版本目录。

## 5. 局部页面更新

只修改一个页面时：

- 仍创建新的原型版本；
- 继承未受影响页面；
- 只重新生成目标页面；
- Manifest 标记每个页面的来源版本；
- 不让不同版本页面散落拼接成“当前原型”。

可记录：

```yaml
page_version_source:
  P-001: proto-20260730-1900
  P-002: proto-20260729-1630
```

## 6. 当前版本、收藏和归档

`current.yaml`：

```yaml
prototype_id:
current_version_id:
current_path:
current_status:
approved_version_id:
source_prd_version_id:
stale:
updated_at:
```

`registry.yaml`：

```yaml
prototype_id:
current_version_id:
approved_version_id:

versions:
  - prototype_version_id:
    path:
    source_prd_version_id:
    status:
    starred:
    stale:
    created_at:
    change_summary:
    content_hash:
```

收藏只更新 `starred`，不复制文件。

## 7. PRD 版本联动

生成或打开原型前比较：

```text
prototype.source_prd_version_id
vs
prd.current_version_id / prd.approved_version_id
```

不一致时：

- 标记 `stale: true`；
- 展示差异摘要；
- 不自动覆盖；
- 提供保留、整体更新、局部更新或切换 PRD 版本的选项。

## 8. 统一浏览入口

功能级 `prototype/catalog.md` 至少展示：

| 原型版本 | 来源 PRD | 状态 | 页面数 | 收藏 | 是否过期 | 创建时间 |
|---|---|---|---:|---|---|---|

工作区根目录的 `catalog.md`（`D:\product-workspace\catalog.md`）汇总所有产品和功能。

## 9. 生成物收纳规则

- 页面代码：`pages/<page-id>-<page-key>/`
- 页面规格：页面同目录的 `page-spec.md`
- 公共组件：`components/`
- 图片和图标：`assets/`
- 模拟数据：`data/`
- Review：`reviews/`
- 页面截图：`snapshots/`
- 原型总说明：版本根目录 `brief.md`

不得把页面文件写入 Skill 文件夹、项目根目录或随机临时目录。

## 10. 输出路径可视化（每次必须）

所有产出文件的最终位置，必须让用户一眼就能看到。每次完成生成或更新后：

1. **汇报完整绝对路径**，不允许只给相对路径或"已保存"这类含糊表述；
2. **输出目录树**，用 Markdown 代码块展示本次实际生成或更新的文件位置；
3. **打开文件管理器**（Windows 下执行 `explorer.exe <产出目录>`），让用户直接看到文件夹；执行失败时忽略，不影响主流程。

固定路径速查（写在每次回复中）：

```text
📁 你的文件在这里

D:\product-workspace\<product-key>\<feature-key>\prototype\versions\<prototype-version-id>\
```

## 11. 不允许

- 只生成多个 HTML 文件但不维护 Manifest；
- 每次在不同目录输出原型；
- 覆盖已批准版本；
- 原型不记录来源 PRD 版本；
- 局部更新后形成跨目录拼接；
- 只在文件名中手工标注 V1、V2；
- 删除版本但不更新 Registry 和 Catalog。
