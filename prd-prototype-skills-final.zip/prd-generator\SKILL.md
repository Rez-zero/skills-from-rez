---
name: prd-generator
description: >
  将用户需求、现有页面、spec、会议纪要、原型截图和项目上下文，
  整理为结构完整、可评审、可验收的 prd.md。
  适用于页面级、功能级、模块级、产品级，以及 AI、Agent、Workflow、Skill 产品。
  输出需包含目标、范围、用户、流程、功能、业务规则、数据、权限、状态、异常、
  非功能要求、埋点、验收标准、风险、待确认项和 prototype_handoff。
version: 2.1.0
language: zh-CN
output_format: markdown
primary_output: prd.md
compatible_skills:
  - ai-prototype-plan
---

# PRD Generator

## 1. 目标

把零散需求转换为可执行的产品需求文档，并为后续 `ai-prototype-plan` 提供稳定输入。

推荐链路：

```text
需求材料
→ prd-generator
→ prd.md
→ 产品经理 Review
→ ai-prototype-plan
→ brief.md
→ AI 原型 / 研发评审
```

本 Skill 负责回答：

- 为什么做；
- 给谁做；
- 做什么、不做什么；
- 用户如何完成任务；
- 页面和功能如何工作；
- 业务规则如何判断；
- 数据和权限如何流转；
- 状态、异常和 Fallback 如何处理；
- 如何验收。

不负责直接输出生产代码、视觉稿、数据库设计或最终商业决策。

---

## 2. 触发场景

在以下请求中使用：

- 生成、补全、重构或审查 PRD；
- 把自然语言需求、会议纪要、页面截图或代码整理成 PRD；
- 为页面、模块、流程、Agent、Workflow 或 Skill 写需求；
- 为后续 AI 原型生成准备产品需求基线。

---

## 3. 必读输入

按优先级读取：

1. 用户本轮需求；
2. 已有 `prd.md`；
3. `spec.md`、README、产品说明；
4. 页面主要实现文件；
5. 关联页面、路由、组件、数据对象；
6. 截图、原型、流程图；
7. 用户反馈、竞品和补充材料。

若存在多个文件，先建立：

- 已确认事实；
- 冲突信息；
- 缺失信息；
- 假设；
- 待确认项。

不得只根据截图猜测后台规则。

---

## 4. 执行流程

### Step 1：识别任务

确认：

```yaml
task_type: 新建 | 补全 | 重构 | 审查
scope_level: 页面级 | 功能级 | 模块级 | 产品级
product_type: 普通产品 | AI | Agent | Workflow | Skill
existing_prd: true | false
prototype_handoff_required: true
```

### Step 2：定位统一文档工作区

读取 `references/document-repository.md`。

确定 `product_key`、`feature_key`、`document_id`、当前版本、已批准版本和历史版本。不得将 PRD 随机写入临时目录，也不得覆盖旧版本。

### Step 3：确定范围

明确：

- 背景与问题；
- 产品目标和非目标；
- 用户角色；
- 核心场景；
- 本次范围和非本次范围；
- 前置依赖；
- 成功标准；
- P0 待确认项。

### Step 4：选择模板

根据页面和任务类型，读取：

- 通用 PRD 骨架：`references/prd-structure.md`
- 页面类型模板：`references/page-templates.md`
- AI/Agent/Skill 模板：`references/ai-agent-template.md`
- PRD 仓库与版本管理：`references/document-repository.md`

一个需求可组合多种模板，不得强行只套一种。

### Step 5：建立需求模型

```yaml
product:
  background:
  problem:
  goal:
  non_goals:
  success_metrics:

users:
  roles:
  permissions:
  scenarios:
  jobs_to_be_done:

scope:
  in_scope:
  out_of_scope:
  dependencies:

experience:
  pages:
  flows:
  states:
  interactions:

requirements:
  functional:
  business_rules:
  data:
  permissions:
  ai:
  non_functional:

validation:
  acceptance_criteria:
  analytics:
  risks:
  open_questions:
```

### Step 6：生成 `prd.md`

使用 `references/prd-structure.md`。

要求：

- 功能需求使用 `FR-xxx`；
- 业务规则使用 `BR-xxx`；
- 验收标准使用 `AC-xxx`；
- 假设使用 `A-xxx`；
- 风险使用 `R-xxx`；
- 页面使用 `P-xxx`；
- 动态模块写明展示和隐藏条件；
- 未确认规则不得写成正式结论。

### Step 7：一致性检查

读取 `references/quality-checklist.md`，至少检查：

- 目标与功能；
- 用户与权限；
- 页面与流程；
- 功能与规则；
- 字段与数据来源；
- 状态与操作；
- 跳转与返回；
- 异常与 Fallback；
- 验收覆盖；
- PRD 内部是否存在冲突。

发现冲突时，先修正文档；无法确认时进入待确认项。

### Step 8：写入版本仓库

按 `references/document-repository.md`：

- 自动生成 `version_id`；
- 保存不可变版本快照；
- 生成变更摘要；
- 更新 `current.yaml`、`registry.yaml` 和 `catalog.md`；
- 维护收藏、评审、批准和归档状态；
- 检查关联原型是否因 PRD 更新而过期。

不得只在标题或文件名中手工维护版本号。

### Step 9：生成原型交接

读取 `references/prototype-handoff.md`，在 PRD 结尾输出固定的 `prototype_handoff`。

交接必须让 `ai-prototype-plan` 无需猜测：

- 页面；
- 入口与出口；
- 核心操作；
- 关键状态；
- 全局业务规则；
- 权限；
- 动态模块；
- 原型范围；
- P0 待确认项。

---

## 5. 缺失信息处理

| 类型 | 定义 | 处理 |
|---|---|---|
| P0 | 不确认会导致核心流程、权限、安全或数据错误 | 必须追问，或显式阻断 |
| P1 | 会显著影响范围、体验或成本 | 使用保守假设继续并标记 |
| P2 | 不影响核心方案 | 使用可回退默认值 |

原则：

- 不因次要信息缺失停止；
- 不擅自拍板收费、权限、合规和商业规则；
- 不把建议写成已确认事实；
- 多个方案并存时，给出推荐方案、备选方案和依据。

---

## 6. AI 产品附加要求

若涉及 AI、Agent、Workflow 或 Skill，必须读取：

`references/ai-agent-template.md`

并覆盖：

- AI 能力边界；
- 输入理解；
- Query、实体、事实和意图提取；
- Skill/Workflow 触发；
- 工具选择、顺序、超时、重试和权限；
- 结构化输出；
- Reference 和引用追溯；
- 长任务状态；
- 无结果、工具失败、冲突和格式错误 Fallback；
- 评测指标；
- Prompt、Skill、模型和工具日志。

---

## 7. 输出规则

主输出为统一工作区中的版本化 PRD：

```text
D:\product-workspace\<product-key>\<feature-key>\prd\versions\<version-id>\prd.md
```

同时维护 `current.yaml`、`registry.yaml`、`catalog.md` 和 `change-summary.md`。

可选输出：

```text
prd-review.md
open-questions.md
data-dictionary.md
event-tracking.md
acceptance-criteria.md
prototype-handoff.md
```

### 路径可视化（每次输出必须）

每次生成或更新完成后，回复末尾必须输出统一的「文件位置卡片」，不得只写相对路径或含糊表述：

```text
📁 你的文件在这里

D:\product-workspace\<product-key>\<feature-key>\prd\versions\<version-id>\prd.md

📂 本次生成的文件

D:\product-workspace\
└── <product-key>\
    └── <feature-key>\
        └── prd\
            ├── registry.yaml
            ├── current.yaml
            └── versions\
                └── <version-id>\
                    ├── prd.md
                    ├── metadata.yaml
                    └── change-summary.md

🔗 已为你打开该文件夹（如未弹出窗口可忽略）
```

要求：

- 路径必须写完整绝对路径；
- 目录树只展示本次实际生成或更新的文件，不虚构；
- 生成完成后执行 `explorer.exe "D:\product-workspace\..."` 打开产出目录，让用户直接看到文件夹（执行失败或环境不支持时忽略，不影响主流程）；
- 若产出目录已存在且本次未产生新文件，仍需在回复中指明当前文件位置。

默认回复只汇报：

- 文件位置（按上方路径卡片格式，必含完整路径与目录树）；
- PRD 类型与范围；
- P0/P1 待确认；
- 一致性检查结果；
- 是否可进入 `ai-prototype-plan`。

---

## 8. 禁止事项

不得：

- 只复述需求；
- 只写页面元素、不写业务规则；
- 只写正常流程、不写异常；
- 只写功能、不写数据、权限和验收；
- 用竞品逻辑替代本产品决策；
- 擅自确定收费、权限或合规规则；
- 把技术实现方案伪装成产品需求；
- 为凑完整度新增无关功能；
- 让原型 Skill 猜测关键规则；
- 跳过一致性检查。
