# PRD 文档仓库与版本管理

本规范用于避免 PRD 散落、覆盖旧版本，或只依靠标题和文件名中的 V1、V2 手工管理。

## 1. 工作区根目录

工作区根目录为：

```
D:\product-workspace\
```

所有 PRD 和原型文件统一收纳在此目录下。

## 2. 默认目录结构

优先继承已有目录。没有规范时使用：

```text
D:\product-workspace\
  registry.yaml
  catalog.md

  /<product-key>
    product.yaml

    /<feature-key>
      feature.yaml

      /prd
        registry.yaml
        current.yaml
        changelog.md

        /versions
          /<prd-version-id>
            prd.md
            metadata.yaml
            change-summary.md

      /prototype
        registry.yaml
        current.yaml
        /versions
```

正式 PRD 不得散落到页面目录、临时输出目录或聊天附件目录。

## 2. 稳定标识

每份 PRD 必须维护：

```yaml
product_key:
feature_key:
document_id:
version_id:
source_version_id:
status: draft | in_review | approved | superseded | archived
starred: false
created_at:
updated_at:
content_hash:
```

规则：

- `document_id` 在同一功能生命周期内保持不变；
- `version_id` 自动生成，不要求用户手工命名 V1、V2；
- `approved` 和 `archived` 版本不得覆盖；
- 修改已批准版本时，必须创建新版本；
- `source_version_id` 指向本版本基于的上一版本。

## 3. 版本生成流程

```text
读取 registry.yaml
→ 定位 document_id
→ 读取当前版本
→ 生成新 version_id
→ 写入不可变版本目录
→ 生成 change-summary.md
→ 更新 current.yaml
→ 更新 registry.yaml
→ 更新 catalog.md
```

以下情况创建新版本：

- 新建 PRD；
- 修改已有 PRD；
- 范围、流程、规则、字段、权限或验收发生变化；
- 形成评审稿、批准稿或归档稿；
- 需要交给原型 Skill 使用。

若内容哈希与当前版本一致：

- 不创建重复版本；
- 返回当前版本；
- 记录“无实质变更”。

## 4. 当前版本和历史版本

`current.yaml`：

```yaml
document_id:
current_version_id:
current_status:
current_path:
approved_version_id:
updated_at:
```

`registry.yaml`：

```yaml
document_id:
product_key:
feature_key:
current_version_id:
approved_version_id:

versions:
  - version_id:
    path:
    status:
    starred:
    created_at:
    source_version_id:
    change_type:
    change_summary:
    content_hash:
    linked_prototype_versions: []
```

## 5. 收藏、批准、归档和恢复

用户可以要求：

- 收藏或取消收藏某个版本；
- 标记为评审中；
- 标记为已批准；
- 归档旧版本；
- 将历史版本恢复为新的当前版本。

收藏通过 `starred: true` 实现，不复制文件。

恢复历史版本时：

- 不覆盖当前版本；
- 以历史版本为 `source_version_id` 创建新版本；
- 在变更摘要中记录恢复来源。

## 6. 变更摘要

每个版本必须生成 `change-summary.md`：

```markdown
# 版本变更摘要

- 版本 ID：
- 基于版本：
- 变更类型：
- 状态：
- 创建时间：

## 新增
## 修改
## 删除
## 未解决问题
## 对原型的影响
## 是否需要重新生成原型
```

不得只写“更新了部分内容”。

## 7. 与原型联动

PRD 必须向原型 Skill 提供：

```yaml
source_prd_document_id:
source_prd_version_id:
source_prd_status:
```

生成新 PRD 版本后，检查已有原型：

- 原型引用旧 PRD 版本时，标记 `stale: true`；
- 不自动覆盖旧原型；
- 允许用户选择保留、整体重建或只更新受影响页面。

## 8. 统一索引

根目录 `catalog.md` 至少展示：

| 产品 | 功能 | PRD 当前版本 | 状态 | 已批准版本 | 收藏版本 | 原型当前版本 | 是否过期 |
|---|---|---|---|---|---|---|---|

`registry.yaml` 供机器读取，`catalog.md` 供人工浏览。

## 9. 输出路径可视化（每次必须）

所有产出文件的最终位置，必须让用户一眼就能看到。每次完成生成或更新后：

1. **汇报完整绝对路径**，不允许只给相对路径或"已保存"这类含糊表述；
2. **输出目录树**，用 Markdown 代码块展示本次实际生成或更新的文件位置；
3. **打开文件管理器**（Windows 下执行 `explorer.exe <产出目录>`），让用户直接看到文件夹；执行失败时忽略，不影响主流程。

固定路径速查（写在每次回复中）：

```text
📁 你的文件在这里

D:\product-workspace\<product-key>\<feature-key>\prd\versions\<version-id>\
```

## 10. 不允许

- 只在标题或文件名中标注版本号；
- 覆盖旧版 `prd.md`；
- 使用 `final-v2-new.md` 一类文件名管理历史；
- 把不同产品的 PRD 放在同一无结构目录；
- 删除历史版本但不记录；
- 原型无法追溯到具体 PRD 版本。
